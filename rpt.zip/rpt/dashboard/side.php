<?php
  $select_username = $pdo->prepare("SELECT * FROM admins");
  $select_username->execute();
  $fetch_username = $select_username->fetch(PDO::FETCH_ASSOC);
?>

<nav>
    <div class="logo">
        <div class="logos">
           <img src="../img/logo.png">
           <span class="town">Towntech Innvation</span>
        </div>
        <i class="fa-solid fa-times closed"></i>
    </div>
    <ul>
        <div class="ava">
           <img class="avatar big" src="../uploads/<?php echo $fetch_username["image_profile"] ?>">
            <div class="user">
                 <p><?php echo $fetch_username['username'];?></p>
             </div> 
        </div>
        <span class="opac">Main</span>
        <li>
            <a href="../dashboard/dash.php">
                <span class="icon"><i class="fa-solid fa-cube"></i></span>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <span class="opac">Admin</span>
        <li>
            <a href="../admins/admins.php">
                <span class="icon"><i class="fa-solid fa-user-tie"></i></span>
                <span class="text">Admin</span>
            </a>
        </li>
        <span class="opac">Reports</span>
        <li>
            <a href="../settings/settings.php">
                <span class="icon"><i class="fa-solid fa-flag"></i></span>
                <span class="text">Reports</span>
            </a>
        </li>

    </ul>
</nav>
