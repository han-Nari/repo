<?php 
	require_once "../includes/rpt_db_connect.php";
	require_once "../includes/session.php";
		
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="\test\finance\img\logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php require_once "dash.css"; ?>
		<?php require_once "../coa/table.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php require_once "side.php";?>

	<!-- Header -->
	<?php require_once "header.php";?>

	<!-- Main content -->
		<section>
			<h1 class="title block">Dashboard</h1>
			<div class="col_one">
				<div class="cards">
					<span class="icon bg-1">
						<i class="fa-solid fa-file-circle-plus"></i>
					</span>
					<span class="texts">
						<span>Personal Services Documents</span>
						<p class="count"><?php //echo servicesCount($pdo); ?></p>
					</span>
					</span>
				</div>
				<div class="cards">
					<span class="icon bg-2">
						<i class="fa-solid fa-file"></i>
					</span>
					<span class="texts">
						<span>Expenses Documents</span>
						<p class="count"><?php //echo expensesCount($pdo); ?></p>
					</span>
				</div>
				<div class="cards">
					<span class="icon bg-3">
						<i class="fa-solid fa-folder"></i>
					</span>
					<span class="texts">
						<span>Rao Documents</span>
						<p class="count"><?php //echo servicesCount($pdo); ?></p>
					</span>
				</div>
				<div class="cards">
					<span class="icon bg-4">
						<i class="fa-solid fa-user-tie"></i>
					</span>
					<span class="texts">
						<span>Admin</span>
						<p class="count"><?php //echo rowCount($pdo); ?></p>
					</span>
				</div>
			</div>
			<div class="col_two">
				<div class="container">
					<div class="auto_scroll">
						<table>
							<caption>
									<span class="left">Recent Documents</span>			
							</caption>
							<thead>
								<tr>
									<th>Document Name</th>
									<th>Sender</th>
									<th>Descriptions</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td data-cell="Document Name">Expense</td>
									<td data-cell="Sender">Lek</td>
									<td data-cell="Descriptions">Supplies</td>
									<td data-cell="Date">2/3/24</td>
								<tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>	
		</section>
	</main>
	<script>
		<?php require_once "dash.js"; ?>
	</script>
</body>
</html>



	