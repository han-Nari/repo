<?php 

session_start();
session_unset();
session_destroy();
header('location:\test\finance\admin_login\admin_login.php');