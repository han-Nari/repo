<?php 

try {
	function servicesCount($pdo) {
		$query = "SELECT * FROM services";
		$stmt = $pdo->prepare($query);
		$stmt->execute();
		return $stmt->rowCount();
	}

} catch(PDOException $e) {
	die("query Failed" . $e->getMessage());
	
}

try {
	function expensesCount($pdo) {
		$query = "SELECT * FROM expenses";
		$stmt = $pdo->prepare($query);
		$stmt->execute();
		return $stmt->rowCount();
	}

} catch(PDOException $e) {
	die("query Failed" . $e->getMessage());
	
}

try {
	function capitalCount($pdo) {
		$query = "SELECT * FROM capital";
		$stmt = $pdo->prepare($query);
		$stmt->execute();
		return $stmt->rowCount();
	}

} catch(PDOException $e) {
	die("query Failed" . $e->getMessage());
	
}